'use client'

import { useState } from 'react'
import { Navbar } from '../components/navbar'
import { Hero } from '../components/hero'
import { About } from '../components/about'
import { Skills } from '../components/skills'
import { Projects } from '../components/projects'
import { Testimonials } from '../components/testimonials'
import { Contact } from '../components/contact'
import { Footer } from '../components/footer'
import { ScrollToTop } from '../components/scroll-to-top'
import { AnimatedBackground } from '../components/animated-background'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <AnimatedBackground />
      <Navbar />
      <main className="flex-grow">
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  )
}

