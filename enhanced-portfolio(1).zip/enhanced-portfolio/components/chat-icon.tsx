'use client'

import { MessageCircle } from 'lucide-react'

interface ChatIconProps {
  onClick: () => void
  position?: 'left' | 'right'
}

export function ChatIcon({ onClick, position = 'right' }: ChatIconProps) {
  const positionClass = position === 'left' ? 'left-4' : 'right-4'

  return (
    <button
      onClick={onClick}
      className={`fixed bottom-4 ${positionClass} p-2 rounded-full bg-primary text-white transition-all duration-300 hover:scale-110`}
      aria-label="Open chat"
    >
      <MessageCircle className="w-6 h-6" />
    </button>
  )
}

