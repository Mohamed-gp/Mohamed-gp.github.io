'use client'

import Image from 'next/image'
import { motion, useScroll, useTransform } from 'framer-motion'
import { Github, Linkedin, Mail, FileDown } from 'lucide-react'
import { useRef } from 'react'

export function Hero() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  })

  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%'])

  return (
    <section ref={ref} className="relative py-20 overflow-hidden bg-gradient-to-br from-primary-100 to-primary-300 dark:from-primary-900 dark:to-primary-700">
      <motion.div style={{ y }} className="absolute inset-0 z-0">
        <Image
          src="/hero-background.jpg"
          alt="Hero background"
          layout="fill"
          objectFit="cover"
          quality={100}
        />
      </motion.div>
      <div className="container relative z-10 mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:w-1/2"
          >
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              Hello, I'm <span className="text-primary-600 dark:text-primary-300">Your Name</span>
            </h1>
            <p className="text-xl text-gray-700 dark:text-gray-300 mb-8">
              A passionate developer crafting innovative solutions across various technologies.
            </p>
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="flex space-x-4"
            >
              <a
                href="#projects"
                className="px-6 py-3 bg-primary-500 text-white rounded-full hover:bg-primary-600 transition duration-300 cursor-pointer shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                View Projects
              </a>
              <a
                href="/your-cv.pdf"
                download
                className="px-6 py-3 bg-white text-primary-500 rounded-full hover:bg-gray-100 transition duration-300 cursor-pointer shadow-lg hover:shadow-xl transform hover:-translate-y-1 flex items-center"
              >
                <FileDown className="w-5 h-5 mr-2" />
                Download CV
              </a>
            </motion.div>
            <div className="mt-8 flex space-x-6">
              <SocialLink href="https://github.com/yourusername" icon={<Github className="w-6 h-6" />} label="GitHub" />
              <SocialLink href="https://linkedin.com/in/yourusername" icon={<Linkedin className="w-6 h-6" />} label="LinkedIn" />
              <SocialLink href="mailto:your.email@example.com" icon={<Mail className="w-6 h-6" />} label="Email" />
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="lg:w-1/2 mt-12 lg:mt-0"
          >
            <div className="relative w-64 h-64 mx-auto">
              <Image
                src="/your-image.jpg"
                alt="Your Name"
                layout="fill"
                objectFit="cover"
                className="rounded-full shadow-2xl"
              />
              <motion.div
                className="absolute -top-4 -right-4 w-72 h-72 border-4 border-primary-300 rounded-full"
                initial={{ rotate: 0 }}
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function SocialLink({ href, icon, label }) {
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-gray-600 hover:text-primary-500 dark:text-gray-300 dark:hover:text-primary-300 transition-colors duration-300 cursor-pointer"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
    >
      {icon}
      <span className="sr-only">{label}</span>
    </motion.a>
  )
}

