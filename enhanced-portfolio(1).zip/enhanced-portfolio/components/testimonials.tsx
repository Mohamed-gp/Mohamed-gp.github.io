'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const testimonials = [
  {
    id: 1,
    name: 'John Doe',
    role: 'CEO at TechCorp',
    content: 'Working with this developer was an absolute pleasure. Their attention to detail and problem-solving skills are unmatched.',
    avatar: '/avatars/john-doe.jpg',
  },
  {
    id: 2,
    name: 'Jane Smith',
    role: 'Project Manager at InnovateTech',
    content: 'I was impressed by the quality of work and the ability to deliver projects on time. Highly recommended!',
    avatar: '/avatars/jane-smith.jpg',
  },
  {
    id: 3,
    name: 'Mike Johnson',
    role: 'CTO at StartupX',
    content: 'The technical expertise and creativity brought to our project were exceptional. We couldn't be happier with the results.',
    avatar: '/avatars/mike-johnson.jpg',
  },
]

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length)
  }

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">What People Say</h2>
        <div className="relative max-w-3xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
              className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg"
            >
              <p className="text-gray-600 dark:text-gray-300 mb-6 text-lg italic">"{testimonials[currentIndex].content}"</p>
              <div className="flex items-center">
                <img src={testimonials[currentIndex].avatar} alt={testimonials[currentIndex].name} className="w-12 h-12 rounded-full mr-4" />
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white">{testimonials[currentIndex].name}</p>
                  <p className="text-gray-600 dark:text-gray-400">{testimonials[currentIndex].role}</p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
          <button
            onClick={prevTestimonial}
            className="absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-full bg-white dark:bg-gray-800 p-2 rounded-full shadow-md"
          >
            <ChevronLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
          </button>
          <button
            onClick={nextTestimonial}
            className="absolute top-1/2 right-0 transform -translate-y-1/2 translate-x-full bg-white dark:bg-gray-800 p-2 rounded-full shadow-md"
          >
            <ChevronRight className="w-6 h-6 text-gray-600 dark:text-gray-300" />
          </button>
        </div>
      </div>
    </section>
  )
}

